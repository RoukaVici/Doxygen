var searchData=
[
  ['validate_5fsize',['validate_size',['../pipe_8c.html#a80d839649ab79c3377b2f11ccd19a7e2',1,'pipe.c']]],
  ['validate_5fsize_5fimpl',['validate_size_impl',['../pipe_8c.html#ab907a893e058e4c720d1f5883e5c6273',1,'pipe.c']]],
  ['validate_5fsize_5flocked',['validate_size_locked',['../pipe_8c.html#a5143ad9eb83f6071fdc7a43382af1e69',1,'pipe.c']]],
  ['verbose',['verbose',['../class_lib_rouka_vici.html#aaaa7bdf1b2778fa1c1dd37f3aec4031b',1,'LibRoukaVici']]],
  ['vibrate',['Vibrate',['../class_lib_rouka_vici.html#a801bc586ec58a1a0afda0cd8977c785b',1,'LibRoukaVici.Vibrate()'],['../class_b_t_manager.html#a940c9593505dd9ab90363f8e8d6309e6',1,'BTManager::Vibrate()'],['../class_device_manager.html#a0548a7e55c66ca8d616e59bc84d3fd35',1,'DeviceManager::Vibrate()'],['../class_raw_manager.html#a4e0361d987a1f4c3e3002d113f24e295',1,'RawManager::Vibrate()'],['../class_rouka_vici.html#adca4be71ac442bc1b2cdf76854fe1c98',1,'RoukaVici::Vibrate()'],['../class_t_c_p_manager.html#ab8844b3d87d2d3d58be2eca65f8a984b',1,'TCPManager::Vibrate()'],['../class_text_manager.html#af715389863dedf52000ed13f43c63715',1,'TextManager::Vibrate()'],['../class_u_s_b_manager.html#a046c7130152e1ebf981e66d05a3c13c6',1,'USBManager::Vibrate()'],['../class_vibration_group.html#ac7b468d2130344988f68e8094bf007ed',1,'VibrationGroup::Vibrate()'],['../_sketch___p_o_c_8ino.html#a776c0f7fe09f9f9c753c41d60b874e8b',1,'vibrate(int n):&#160;Sketch_POC.ino'],['../_lib_rouka_vici_8h.html#a1662668dfac68286f47ef4ac50bda198',1,'Vibrate():&#160;LibRoukaVici.h'],['../_rouka_vici_a_p_i_8cpp.html#a2bd1136a02de816ffa7159dbbde438bb',1,'Vibrate(char motor, char intensity):&#160;RoukaViciAPI.cpp'],['../_rouka_vici_a_p_i_8h.html#adf0ddc788adc8be1a04adf9ce31df053',1,'Vibrate(char motor, char intensity):&#160;RoukaViciAPI.cpp']]],
  ['vibrategroup',['VibrateGroup',['../class_lib_rouka_vici.html#ad6ddb67d70f470bca6a566c581c6cf28',1,'LibRoukaVici.VibrateGroup(char[] name, char intensity)'],['../class_lib_rouka_vici.html#ab52826f07da18dd6cb813cb125f855d2',1,'LibRoukaVici.VibrateGroup(string name, char intensity)'],['../class_group_manager.html#aacb147558d397927b0461f4bf7a70029',1,'GroupManager::VibrateGroup()'],['../class_rouka_vici.html#afad2ced7440ccac696680a53c7d68a94',1,'RoukaVici::VibrateGroup()'],['../_rouka_vici_a_p_i_8cpp.html#ab5acc711ab016520351d653448a56997',1,'VibrateGroup(const char *const name, char intensity):&#160;RoukaViciAPI.cpp'],['../_rouka_vici_a_p_i_8h.html#ac0c34a49901e8edad9e98ec21cbac6b4',1,'VibrateGroup(const char *name, char intensity):&#160;RoukaViciAPI.cpp']]],
  ['vibrating',['vibrating',['../class_activate_pattern.html#a22b5860a1d7ae6f18becf493d4421671',1,'ActivatePattern.vibrating()'],['../class_clicked.html#acf43e77da62bd20bc38086df385f34ac',1,'Clicked.vibrating()']]],
  ['vibrationgroup',['VibrationGroup',['../class_vibration_group.html',1,'VibrationGroup'],['../class_vibration_group.html#a47b4c74ad791dd878cfaaa4b4f007d53',1,'VibrationGroup::VibrationGroup()']]],
  ['vibrationgroup_2ecpp',['VibrationGroup.cpp',['../_vibration_group_8cpp.html',1,'']]],
  ['vibrationgroup_2ehh',['VibrationGroup.hh',['../_vibration_group_8hh.html',1,'']]],
  ['vibrationpatternparser_2ecpp',['VibrationPatternParser.cpp',['../_vibration_pattern_parser_8cpp.html',1,'']]],
  ['vibrationpatternparser_2eh',['VibrationPatternParser.h',['../_vibration_pattern_parser_8h.html',1,'']]],
  ['vibrationpatterns',['vibrationPatterns',['../class_rouka_vici_controller.html#adc76226efee4153dbc2ac91a163ed8c5',1,'RoukaViciController']]],
  ['vibrationselectionwidget_2ecpp',['VibrationSelectionWidget.cpp',['../_vibration_selection_widget_8cpp.html',1,'']]],
  ['vibrationselectionwidget_2eh',['VibrationSelectionWidget.h',['../_vibration_selection_widget_8h.html',1,'']]],
  ['vibrationstyle',['VibrationStyle',['../class_vibration_style.html',1,'']]],
  ['vibrationstyle_2ecs',['VibrationStyle.cs',['../_vibration_style_8cs.html',1,'']]]
];
