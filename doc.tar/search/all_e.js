var searchData=
[
  ['name',['name',['../class_vibration_style.html#a32b7945d8449db018f778c37a14d88a9',1,'VibrationStyle.name()'],['../struct_fm_pattern.html#ab4fef5d3751c8d518a3bc95dd4173a75',1,'FmPattern::name()'],['../structdevice.html#ac0ed9729afb86b4d1e833ee79b8bbb55',1,'device::name()'],['../structdevice__info__t.html#a034f7565fdffd67f7658c2e00e22b27b',1,'device_info_t::name()'],['../class_vibration_group.html#ad4bfc828884b7840998ced27481061a2',1,'VibrationGroup::name()']]],
  ['nativeconstruct',['NativeConstruct',['../class_u_vibration_selection_widget.html#a5cd02435408f98ff64901383b139daca',1,'UVibrationSelectionWidget']]],
  ['newgroup',['NewGroup',['../class_lib_rouka_vici.html#a8b1cf710d9f81a854e9f4a8b4fe7ccf0',1,'LibRoukaVici.NewGroup(char[] name)'],['../class_lib_rouka_vici.html#a9215366def0239e4a904a514b1abe881',1,'LibRoukaVici.NewGroup(string name)'],['../class_group_manager.html#a731ed05e88a8aa72c8e1f2ce1928377c',1,'GroupManager::NewGroup()'],['../class_rouka_vici.html#a8cdec4102618b9150e96d0f41c11b1fe',1,'RoukaVici::NewGroup()'],['../_rouka_vici_a_p_i_8cpp.html#ad27c596068bbba89b52129ddf73a3538',1,'NewGroup(const char *const name):&#160;RoukaViciAPI.cpp'],['../_rouka_vici_a_p_i_8h.html#ae5700b16ef8706409765deaa15190cc2',1,'NewGroup(const char *name):&#160;RoukaViciAPI.cpp']]],
  ['next_5fpow2',['next_pow2',['../pipe_8c.html#a87d9f1fddf7557d9121389bbb536a89d',1,'pipe.c']]],
  ['no_5fnull_5fpointers',['NO_NULL_POINTERS',['../pipe_8h.html#a8a3c90738ceb8720dcb81e6f9eb3541e',1,'pipe.h']]],
  ['noexcept',['NOEXCEPT',['../_bluetooth_exception_8h.html#a10a59554805ac7ce3905fd3540f98137',1,'BluetoothException.h']]]
];
