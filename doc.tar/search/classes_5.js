var searchData=
[
  ['groupmanager',['GroupManager',['../class_group_manager.html',1,'']]]
];
