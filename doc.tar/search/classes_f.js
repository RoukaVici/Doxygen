var searchData=
[
  ['wrapper',['Wrapper',['../class_json_helper_1_1_wrapper.html',1,'JsonHelper']]]
];
