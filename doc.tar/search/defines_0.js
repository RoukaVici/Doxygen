var searchData=
[
  ['_5fcrt_5fsecure_5fno_5fwarnings',['_CRT_SECURE_NO_WARNINGS',['../windows_2_device_i_n_q_8cc.html#af08ec37a8c99d747fb60fa15bc28678b',1,'DeviceINQ.cc']]],
  ['_5fwinsock_5fdeprecated_5fno_5fwarnings',['_WINSOCK_DEPRECATED_NO_WARNINGS',['../windows_2_b_t_serial_port_binding_8cc.html#adfc8f90f3a8caa8423099cf36ff214f1',1,'_WINSOCK_DEPRECATED_NO_WARNINGS():&#160;BTSerialPortBinding.cc'],['../windows_2_device_i_n_q_8cc.html#adfc8f90f3a8caa8423099cf36ff214f1',1,'_WINSOCK_DEPRECATED_NO_WARNINGS():&#160;DeviceINQ.cc']]]
];
