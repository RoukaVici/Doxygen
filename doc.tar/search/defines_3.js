var searchData=
[
  ['default_5fmincap',['DEFAULT_MINCAP',['../pipe_8c.html#af100abdaea32ea66d2ace3094bf55e8f',1,'pipe.c']]]
];
