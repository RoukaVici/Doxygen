var searchData=
[
  ['pipe_5fgeneric',['PIPE_GENERIC',['../pipe_8h.html#ae28710209cc73b0666b3fae09b8c3407',1,'pipe.h']]],
  ['pipify',['PIPIFY',['../pipe_8c.html#abc63fc632a2562f533e52798237d55a2',1,'pipe.c']]],
  ['pure',['PURE',['../pipe_8c.html#acd42770aecb025cfac170d4d3ace4544',1,'PURE():&#160;pipe.c'],['../pipe_8h.html#acd42770aecb025cfac170d4d3ace4544',1,'PURE():&#160;pipe.h']]]
];
