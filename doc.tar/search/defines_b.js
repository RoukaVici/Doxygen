var searchData=
[
  ['rfcomm_5fuuid',['RFCOMM_UUID',['../_bluetooth_worker_8mm.html#a99de4272f1e0e493e782258ba0a2025c',1,'BluetoothWorker.mm']]]
];
