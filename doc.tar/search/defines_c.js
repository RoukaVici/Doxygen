var searchData=
[
  ['tscanf',['tscanf',['../windows_2_device_i_n_q_8cc.html#afcdc8cd3dc568420b5c46e9912276fef',1,'DeviceINQ.cc']]]
];
