var searchData=
[
  ['groupmanager_2ecpp',['GroupManager.cpp',['../_group_manager_8cpp.html',1,'']]],
  ['groupmanager_2ehh',['GroupManager.hh',['../_group_manager_8hh.html',1,'']]]
];
