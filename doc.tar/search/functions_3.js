var searchData=
[
  ['callback',['callback',['../_debug_8cpp.html#af708e0256fda627da5ed1c561776c976',1,'Debug.cpp']]],
  ['callsetlogmode',['callSetLogMode',['../class_u_lib_rouka_vici.html#a52b77695a581a990833ea1c6b0b1cbc5',1,'ULibRoukaVici']]],
  ['callstoplib',['callStopLib',['../class_u_lib_rouka_vici.html#a2dae94f076533c89c8add1d2b3c5a109',1,'ULibRoukaVici']]],
  ['callvibrate',['callVibrate',['../class_u_lib_rouka_vici.html#a9d4faff80b06ee5b750293461c22d77b',1,'ULibRoukaVici']]],
  ['canceledit',['cancelEdit',['../class_pattern_editor_data.html#aab3ab3a5f0fca9f7be5efb5846c038a4',1,'PatternEditorData']]],
  ['capacity',['capacity',['../pipe_8c.html#a843bc321addf5d36f76dd1e30847e73d',1,'pipe.c']]],
  ['changedevicemanager',['ChangeDeviceManager',['../class_lib_rouka_vici.html#a2d83f3a58d05d343fe85b0808e97adc6',1,'LibRoukaVici.ChangeDeviceManager(char[] name)'],['../class_lib_rouka_vici.html#a78abb605fdd22b478b59af2d8df55bcc',1,'LibRoukaVici.ChangeDeviceManager(string name)'],['../class_rouka_vici.html#a173e37f10f5653359c7d840f564e19fa',1,'RoukaVici::ChangeDeviceManager()'],['../_rouka_vici_a_p_i_8cpp.html#a01fd6f13cdf8ee1cf26e196e58c410b3',1,'ChangeDeviceManager(const int idx):&#160;RoukaViciAPI.cpp'],['../_rouka_vici_a_p_i_8h.html#a0a36dce8254c1c596b73c42d7224412d',1,'ChangeDeviceManager(const int idx):&#160;RoukaViciAPI.cpp']]],
  ['check_5finvariants',['check_invariants',['../pipe_8c.html#af2662219ad47a52e3535d9ecb560eb85',1,'pipe.c']]],
  ['close',['Close',['../class_b_t_serial_port_binding.html#ac93faaab18090e76acb5dd2eaa68a8e3',1,'BTSerialPortBinding']]],
  ['connect',['Connect',['../class_b_t_serial_port_binding.html#a75c3e66c139282c040cac43630449961',1,'BTSerialPortBinding']]],
  ['connectdevice_3aonchannel_3awithpipe_3a',['connectDevice:onChannel:withPipe:',['../interface_bluetooth_worker.html#afaf7b37f19939611cfefdfc8ce281a5c',1,'BluetoothWorker']]],
  ['converttime',['ConvertTime',['../windows_2_device_i_n_q_8cc.html#a4b9f9a397ad7f4ff93d0c83022bf0cc0',1,'DeviceINQ.cc']]],
  ['copy_5fpipe_5finto_5fnew_5fbuf',['copy_pipe_into_new_buf',['../pipe_8c.html#a6aa2a1ef1227148a199ab9579b3f3959',1,'pipe.c']]],
  ['create',['Create',['../class_b_t_serial_port_binding.html#a3224111eac07518e3d6ebbeeaeb7f74f',1,'BTSerialPortBinding::Create()'],['../class_device_i_n_q.html#ae060e4efff29e364c15ce15af8862819',1,'DeviceINQ::Create()'],['../class_b_t_manager.html#a7c65ba88e8eeb33f931233afc99ea185',1,'BTManager::create()'],['../class_raw_manager.html#a8b3092f4dc0c09976fc6652cd8706b65',1,'RawManager::create()'],['../class_t_c_p_manager.html#ac1515f1fe116c93a8e3af7edcaf09645',1,'TCPManager::create()'],['../class_text_manager.html#a36046c78262c2244aa063a0b0106ea77',1,'TextManager::create()'],['../class_u_s_b_manager.html#a2ba292c82e613430bc2f01df7567ddb5',1,'USBManager::create()']]]
];
