var searchData=
[
  ['deallocate',['deallocate',['../pipe_8c.html#a41161a1fe5435757c2c196512d72cc6b',1,'pipe.c']]],
  ['declare_5fdynamic_5fmulticast_5fdelegate',['DECLARE_DYNAMIC_MULTICAST_DELEGATE',['../_vibration_selection_widget_8h.html#a92d20d9b198a80d6f7eee98f81ed7378',1,'VibrationSelectionWidget.h']]],
  ['deviceinq',['DeviceINQ',['../class_device_i_n_q.html#a14d5a4ff1845ad90f2494295771c2d4d',1,'DeviceINQ']]],
  ['deviceinquirycomplete_3aerror_3aaborted_3a',['deviceInquiryComplete:error:aborted:',['../interface_bluetooth_worker.html#a6665c20fd409ba896a09d45295d14a0a',1,'BluetoothWorker']]],
  ['deviceinquirydevicefound_3adevice_3a',['deviceInquiryDeviceFound:device:',['../interface_bluetooth_worker.html#ad37df2777bb2f0751acfdef57df3b189',1,'BluetoothWorker']]],
  ['disconnectfromdevice_3a',['disconnectFromDevice:',['../interface_bluetooth_worker.html#a66a0b532d3f5659bd8664800096fc8ef',1,'BluetoothWorker']]],
  ['displayiteration',['displayIteration',['../class_pattern_editor_data.html#a80f17bbc92907f302f25296e0265a119',1,'PatternEditorData']]],
  ['displaypatterneditormenu',['displayPatternEditorMenu',['../class_menu_manager.html#aa127fbc4edced443210b571fca36a372',1,'MenuManager']]],
  ['displaypatternlist',['displayPatternList',['../class_menu_manager.html#a7643cbd686e9c1ba9937a3af7a0f795e',1,'MenuManager']]]
];
