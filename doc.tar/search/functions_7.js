var searchData=
[
  ['get',['get',['../class_manager_factory.html#a6518a4cbf4c26e431420c839fe5eca74',1,'ManagerFactory']]],
  ['get_5fopts',['get_opts',['../main_8c.html#af0c22cb994026fc57dc0a6c9a5372dc8',1,'main.c']]],
  ['getdelay',['getDelay',['../class_vibration_style.html#ae10f1e305236359c04a87800d44721a4',1,'VibrationStyle']]],
  ['getdeviceclassstring',['GetDeviceClassString',['../_enums_8cc.html#a51ebf4418620ed749b1e839bc3edec4b',1,'GetDeviceClassString(DeviceClass deviceClass):&#160;Enums.cc'],['../_enums_8h.html#a0bc24c5ce6616bf561a39909788f2d86',1,'GetDeviceClassString(DeviceClass deviceClass):&#160;Enums.cc']]],
  ['getfiles',['getFiles',['../class_pattern_generator.html#ad71a2ef60d574bfa7c5b0d6ffba1ef73',1,'PatternGenerator']]],
  ['getfingerbyid',['getFingerById',['../class_vibration_style.html#a9db0eda735f3e6006d5b9c1a8666cc27',1,'VibrationStyle']]],
  ['getfingerpattern',['getFingerPattern',['../class_a_rouka_vici_controller.html#a62f557018fda94f717a44c3f59b8bb11',1,'ARoukaViciController']]],
  ['getfingers',['getFingers',['../class_vibration_style.html#a13157a9514881a3b5b442d81893346a5',1,'VibrationStyle']]],
  ['getid',['getId',['../class_fingers.html#a6241c4d54255bf9e46cd3bffd11a791d',1,'Fingers']]],
  ['getinstance',['getInstance',['../interface_bluetooth_worker.html#a28f74c3e6998bf4c7c95306b1227d75c',1,'BluetoothWorker']]],
  ['getiteration',['getIteration',['../class_pattern_editor_data.html#a29584c7e5b6bdb6dc17e2e8e01b06452',1,'PatternEditorData']]],
  ['getlogmode',['GetLogMode',['../class_rouka_vici.html#adf4bf88f004de1f132c14d113b07380e',1,'RoukaVici::GetLogMode()'],['../namespace_debug.html#a06b40a2c0e64cb03e42365926ee14198',1,'Debug::GetLogMode()'],['../_rouka_vici_a_p_i_8cpp.html#a2ddd356623e89d1cce3fde2c9315e1ef',1,'GetLogMode():&#160;RoukaViciAPI.cpp'],['../_rouka_vici_a_p_i_8h.html#abe52cea3d1f092cbfa920456ab725eda',1,'GetLogMode():&#160;RoukaViciAPI.cpp']]],
  ['getname',['getName',['../class_vibration_style.html#af742f5c0f2b859f0ad28252576d67a2b',1,'VibrationStyle']]],
  ['getpattern',['getPattern',['../class_fingers.html#a5df84d1f59b3555e4c39724288cceb1c',1,'Fingers']]],
  ['getpatternbyid',['getPatternById',['../class_fingers.html#a4b436fcbcb2b15193b509de5e7936efa',1,'Fingers']]],
  ['getrfcommchannelid_3a',['getRFCOMMChannelID:',['../interface_bluetooth_worker.html#a5c9be7ac81c5e09db67c9271f4b6ebaa',1,'BluetoothWorker']]],
  ['getserviceclassstring',['GetServiceClassString',['../_enums_8cc.html#af1b84f5cc77fd4372d8865958d2cf79b',1,'GetServiceClassString(ServiceClass serviceClass):&#160;Enums.cc'],['../_enums_8h.html#a2a63bb8124e83dbec23b609a7631e09a',1,'GetServiceClassString(ServiceClass serviceClass):&#160;Enums.cc']]],
  ['getwsaerrormessage',['GetWSAErrorMessage',['../class_bluetooth_helpers.html#a1623259e7bc665a7cc56af5702c693e5',1,'BluetoothHelpers']]],
  ['groupmanager',['GroupManager',['../class_group_manager.html#abc630eff6ffdbd49eb52a40be284aa71',1,'GroupManager']]]
];
