var searchData=
[
  ['hasdevice',['HasDevice',['../class_b_t_manager.html#ab0431856e8465a28715278dc772b75d4',1,'BTManager::HasDevice()'],['../class_device_manager.html#a454c80dbb5019e08ec75ea5876daa04b',1,'DeviceManager::HasDevice()'],['../class_raw_manager.html#a7b99a0bf047853be2381b47714b8aff1',1,'RawManager::HasDevice()'],['../class_t_c_p_manager.html#ac8ea674d1d302f44ead31244e187dca0',1,'TCPManager::HasDevice()'],['../class_text_manager.html#a7b6867cdf4a2bb4d5c1c970c15c589c6',1,'TextManager::HasDevice()'],['../class_u_s_b_manager.html#a2e668b7b978b8c3093d43caa06b998b4',1,'USBManager::HasDevice()']]]
];
