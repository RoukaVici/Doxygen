var searchData=
[
  ['rawmanager',['RawManager',['../class_raw_manager.html#a8eca74ac21d9308e3e9471f39b8d0585',1,'RawManager']]],
  ['read',['Read',['../class_b_t_serial_port_binding.html#a5ab90506480d478d46220ff16cdc25f4',1,'BTSerialPortBinding']]],
  ['rearrangebuttons',['rearrangeButtons',['../class_menu_manager.html#a673967b13b35049463c9f7063edcc44a',1,'MenuManager']]],
  ['registercallback',['RegisterCallback',['../namespace_debug.html#a94811ad6bda942b12fb1c6c25d3a1e62',1,'Debug']]],
  ['registerdebugcallback',['RegisterDebugCallback',['../class_rouka_vici.html#a9663f8ab146111872e53f8d51c7f867e',1,'RoukaVici::RegisterDebugCallback()'],['../_rouka_vici_a_p_i_8cpp.html#ac10b7582b3bc0df9427b98cb003b038a',1,'RegisterDebugCallback(DebugCallback cb):&#160;RoukaViciAPI.cpp'],['../_rouka_vici_a_p_i_8h.html#a3c8ca29439ac857e87329535b521cb6f',1,'RegisterDebugCallback(DebugCallback cb):&#160;RoukaViciAPI.cpp']]],
  ['registerunitycallback',['RegisterUnityCallback',['../namespace_debug.html#a0c90669fe3c8ea273f68e946183db911',1,'Debug']]],
  ['registerunitydebugcallback',['RegisterUnityDebugCallback',['../class_lib_rouka_vici.html#a4ff05cd864dcc7a8a9c467b38a7639cd',1,'LibRoukaVici.RegisterUnityDebugCallback()'],['../class_rouka_vici.html#a05f029855ca5180dbc1277d4ab691a74',1,'RoukaVici::RegisterUnityDebugCallback()'],['../_rouka_vici_a_p_i_8cpp.html#a7ad71e7ee9705621f8c9700cf18d01a5',1,'RegisterUnityDebugCallback(UnityDebugCallback cb):&#160;RoukaViciAPI.cpp'],['../_rouka_vici_a_p_i_8h.html#aab333bb514ea3c7a7f98b8a88f53b9d1',1,'RegisterUnityDebugCallback(UnityDebugCallback cb):&#160;RoukaViciAPI.cpp']]],
  ['removeiteration',['removeIteration',['../class_pattern_editor_data.html#affcb5d56570552cdcca8f2427753f9e6',1,'PatternEditorData']]],
  ['removepattern',['removePattern',['../class_menu_manager.html#a9a9afdb988cca7d2dafe1f588a81381f',1,'MenuManager']]],
  ['resize_5fbuffer',['resize_buffer',['../pipe_8c.html#adbeab23e9ecf69603b3829de709e832d',1,'pipe.c']]],
  ['rfcommchannelclosed_3a',['rfcommChannelClosed:',['../interface_bluetooth_worker.html#a9f5eed4cb736d3f26de8b6ee42152e44',1,'BluetoothWorker']]],
  ['rfcommchanneldata_3adata_3alength_3a',['rfcommChannelData:data:length:',['../interface_bluetooth_worker.html#a1be0dd29680a086fb8b3cb1c1d17efd1',1,'BluetoothWorker']]],
  ['rfcommchannelwritecomplete_3arefcon_3astatus_3a',['rfcommChannelWriteComplete:refcon:status:',['../interface_bluetooth_worker.html#a6cb09465e06dd4fdc2dfc7b8e9e3b0b5',1,'BluetoothWorker']]],
  ['rm',['Rm',['../class_vibration_group.html#a76113cd6f82d26306323bf67bc49174b',1,'VibrationGroup']]],
  ['rmfromgroup',['RmFromGroup',['../class_lib_rouka_vici.html#af91c7b3c8af06e40faf8bc42ef900838',1,'LibRoukaVici.RmFromGroup(char[] name, char motor)'],['../class_lib_rouka_vici.html#a75b1556dc057c62241cc05584c5fdbb4',1,'LibRoukaVici.RmFromGroup(string name, char motor)'],['../class_group_manager.html#a4424787da92c98231da7e965e4c498c3',1,'GroupManager::RmFromGroup()'],['../class_rouka_vici.html#adc5f2628a2388d3b672ebdc84c03943d',1,'RoukaVici::RmFromGroup()'],['../_rouka_vici_a_p_i_8cpp.html#a1c4e199601d13e10a907649cfdf8b5f7',1,'RmFromGroup(const char *const name, char motor):&#160;RoukaViciAPI.cpp'],['../_rouka_vici_a_p_i_8h.html#a4ec640212feae1a46c0662892be8f1f2',1,'RmFromGroup(const char *name, char motor):&#160;RoukaViciAPI.cpp']]],
  ['roukavici',['RoukaVici',['../class_rouka_vici.html#a5d02da64911c77bf55edc7af5d617ba7',1,'RoukaVici.RoukaVici(ReadOnlyTargetRules Target)'],['../class_rouka_vici.html#ad28173fa93269649889460befa63d91e',1,'RoukaVici::RoukaVici()']]],
  ['roukavicieditortarget',['RoukaViciEditorTarget',['../class_rouka_vici_editor_target.html#a488212e7ed9ce7ffc2984c2baf53b495',1,'RoukaViciEditorTarget']]],
  ['roukavicitarget',['RoukaViciTarget',['../class_rouka_vici_target.html#a6af495398611b4503270db32cb708445',1,'RoukaViciTarget']]]
];
