var searchData=
[
  ['debug',['Debug',['../namespace_debug.html',1,'']]]
];
