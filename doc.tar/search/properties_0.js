var searchData=
[
  ['instance',['instance',['../class_lib_rouka_vici.html#a91643f69927dface74253b9293a8f546',1,'LibRoukaVici.instance()'],['../class_rouka_vici_controller.html#a426d32c0d020578d218dede416d0dc23',1,'RoukaViciController.instance()']]]
];
