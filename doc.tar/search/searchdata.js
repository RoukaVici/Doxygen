var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvw~",
  1: "abcdfgjlmprstuvw",
  2: "cd",
  3: "abcdefgiklmprstuv",
  4: "_abcdefghilmnoprstuvw~",
  5: "_abcdefghijklmnoprstuvw",
  6: "adipstuv",
  7: "dms",
  8: "dlrs",
  9: "i",
  10: "_acdeilmnoprtuw",
  11: "mpr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "properties",
  10: "defines",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Properties",
  10: "Macros",
  11: "Pages"
};

