var searchData=
[
  ['initrvici',['InitRVici',['../_lib_rouka_vici_8h.html#a63dc59947832947138a543e8e6962d0b',1,'LibRoukaVici.h']]]
];
