var searchData=
[
  ['setlogmode',['SetLogMode',['../_lib_rouka_vici_8h.html#ac2e3f0a70353b81e9b3700f3394c0627',1,'LibRoukaVici.h']]],
  ['stoprvici',['StopRVici',['../_lib_rouka_vici_8h.html#a23632787ad894a54c5bc3f69e094eb2c',1,'LibRoukaVici.h']]]
];
