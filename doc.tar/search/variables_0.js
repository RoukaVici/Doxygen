var searchData=
[
  ['_5finstance',['_instance',['../class_lib_rouka_vici.html#a554551dcf4c5122a3d04d9680e73cfab',1,'LibRoukaVici._instance()'],['../class_rouka_vici_controller.html#a61f7798c030f65948716761c82f28906',1,'RoukaViciController._instance()']]],
  ['_5fpipe_5fcopyright',['_pipe_copyright',['../pipe_8c.html#a451336b1ac2a78481de3939a101288ec',1,'pipe.c']]]
];
