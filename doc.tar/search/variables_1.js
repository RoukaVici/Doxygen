var searchData=
[
  ['activatedcolor',['activatedColor',['../class_clicked.html#aa88406c4cadffa58b9103b3b0f6dfca0',1,'Clicked']]],
  ['address',['address',['../class_b_t_serial_port_binding.html#a457db55aa66babaae439784aabd1785d',1,'BTSerialPortBinding::address()'],['../structdevice.html#ad5bf91def494577920e8ab7a9e1f217b',1,'device::address()'],['../structdevice__info__t.html#a62e48fb92d8a64e7ada34cdbeac28866',1,'device_info_t::address()'],['../interface_b_t_data.html#a63923a7d77123d7a7a007b40233aa568',1,'BTData::address()']]],
  ['assignedkey',['assignedKey',['../class_clicked.html#a44b961ebc768e141c99e01aafcceeaf3',1,'Clicked']]],
  ['authenticated',['authenticated',['../structdevice.html#aa410eb4e09cb3fdb0c2ed2ca7de1451c',1,'device']]]
];
