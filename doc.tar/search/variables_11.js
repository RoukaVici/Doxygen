var searchData=
[
  ['remembered',['remembered',['../structdevice.html#a40a02baf4ef148968ab8d3fc61a59d41',1,'device']]],
  ['removepattern',['removePattern',['../class_pattern_data.html#a4951a6068a47e3a8d843779d1bf790e6',1,'PatternData']]],
  ['rend',['rend',['../class_clicked.html#a38b3531aca9684132bb2e94ea7b64b4a',1,'Clicked']]],
  ['rep',['rep',['../structbluetooth__data.html#a19addd260fb254a18128ed48a4e0ad9e',1,'bluetooth_data']]],
  ['rpi',['rpi',['../class_u_s_b_manager.html#a2bca33400918ba48d7efebfc9fda16b0',1,'USBManager']]],
  ['rssi',['rssi',['../structdevice__info__t.html#a2f5037b9b75d94feced84cd108c9510d',1,'device_info_t']]],
  ['rv',['rv',['../_rouka_vici_a_p_i_8cpp.html#acfb3ea32497175c804b346079949d03b',1,'RoukaViciAPI.cpp']]]
];
