var searchData=
[
  ['verbose',['verbose',['../class_lib_rouka_vici.html#aaaa7bdf1b2778fa1c1dd37f3aec4031b',1,'LibRoukaVici']]],
  ['vibrating',['vibrating',['../class_activate_pattern.html#a22b5860a1d7ae6f18becf493d4421671',1,'ActivatePattern.vibrating()'],['../class_clicked.html#acf43e77da62bd20bc38086df385f34ac',1,'Clicked.vibrating()']]],
  ['vibrationpatterns',['vibrationPatterns',['../class_rouka_vici_controller.html#adc76226efee4153dbc2ac91a163ed8c5',1,'RoukaViciController']]]
];
