var searchData=
[
  ['groups',['groups',['../class_group_manager.html#aa78cb583fba5c27406de5c8069a535ca',1,'GroupManager']]],
  ['grps',['grps',['../class_rouka_vici.html#a12a5c0491e069162e8006e51ad969653',1,'RoukaVici']]]
];
