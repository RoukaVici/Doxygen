var searchData=
[
  ['host',['HOST',['../_t_c_p_manager_8cpp.html#ae2919fb4882ad0551f173fa6c6e9cbcd',1,'TCPManager.cpp']]]
];
