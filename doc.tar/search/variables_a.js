var searchData=
[
  ['just_5fpopped',['just_popped',['../structpipe__t.html#ab58717ab3900b5557085666b1862d456',1,'pipe_t']]],
  ['just_5fpushed',['just_pushed',['../structpipe__t.html#afcc86e5736580899f60da6d3427d7fad',1,'pipe_t']]]
];
