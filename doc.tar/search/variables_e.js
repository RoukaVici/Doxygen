var searchData=
[
  ['name',['name',['../class_vibration_style.html#a32b7945d8449db018f778c37a14d88a9',1,'VibrationStyle.name()'],['../struct_fm_pattern.html#ab4fef5d3751c8d518a3bc95dd4173a75',1,'FmPattern::name()'],['../structdevice.html#ac0ed9729afb86b4d1e833ee79b8bbb55',1,'device::name()'],['../structdevice__info__t.html#a034f7565fdffd67f7658c2e00e22b27b',1,'device_info_t::name()'],['../class_vibration_group.html#ad4bfc828884b7840998ced27481061a2',1,'VibrationGroup::name()']]]
];
